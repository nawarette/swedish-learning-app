// file:///Users/bentoblitzz/Documents/Playground/svenska_ovning/content/structure.md



svenska_ovning/                                     (Root folder)
    ├─ index.html                                   (Homepage where people can choose the language)
    ├─ global/                                      (Stylesheet, icons, images, javascript folder)
        ├─ style/                                   (Style folder)
        │   ├─ style.css                            (Stylesheet for the whole site)
        │   ├─ favicon/                             (Favicon folder)
        │   └─ images/                              (Images folder)
        ├─ engine/                                  (Javacript folder)
        │   └─ /*/                                  .js / jason files
        └─ content/                                 (Content folder)
            ├─ jp/                                  (Japanese language folder)
            └─ en/                                  (English language folder)
                ├─ dictation/                       (Dictation Practice)   
                └─ grammar/                         (Dictation Practice)
                    ├─ subs/                        (Noun Practice)   
                    │   └─ subs_konjugation/        (Noun conjugation)  
                    │       ├─ A1_A2                (Level A1/A2)
                    │       │   └ subs_konsumtion/  (Substantive Konsumtion folder)
                    │       │       ├─ subs_konsumtion.html      (.html file)
                    │       │       └─ subs_konsumtion_data.js   (.js file for practice words     
                    │       └─ B1/B2                (Level B1/B2)
                    ├─ pronomen/                     (Pronoun Practice)  
                    ├─ verb/                        (Verb Practice)   
                    │   └─ verb conjugation/        (Verb conjugation)  
                    │       ├─ A1_A2                (Level A1/A2)
                    │       └─ B1_B2                (Level B1/B2)
                    ├─ adjektiv/                    (Adjective Practice)   
                    │   ├─ adj_konjugation/         (Adj conjugation)  
                    │   │   ├─ A1_A2                (Level A1/A2)
                    │   │   └─ B1_B2                (Level B1/B2)
                    │   └─ adj_komparation/         (Adj comparison)  
                    │           ├─ A1_A2            (Level A1/A2)
                    │           └─ B1_B2            (Level B1/B2)
                    ├─ adverb/                      (Adverb Practice)   
                    │   ├─ adverb of time           (Adverb of time)  
                    │   ├─ adverb of frequency      (Adverb of frequency) 
                    │   ├─ adverb of place          (Adverb of place)
                    │   └─ /*/                      (Other adverb categories)
                    ├─ preposition/                 (Preposition Practice)
                    ├─ konjunktion/                 (Conjunction Practice)
                    └─ nummer/tid/m.m/              (Numbers, time, etc. Practice)
                        ├─ nummer_tid_mm.html
                        ├─ num_ordinaltal/
                        │  └─ A1_A2/
                        │     ├─ num_ordinaltal.html
                        │     └─ num_ordinaltal_data.js
                        ├─ klockan/
                        │  └─ A1_A2/
                        │     ├─ klockan.html
                        │     └─ klockan_data.js
                        ├─ tidsuttryck/  <-- (Crucial for B1/B2 level!)
                        │  └─ B1_B2/
                        └─ matt_mangd/







# Table mapping example (from subs_konsumtion.html)

| Artikel [input_hint] | Singular (Obestämd) [hint] | Singular (Bestämd) [input] | Plural (Obestämd) [input] | Plural (Bestämd) [input] | Group [group] | Kontroll [control] | Översättning [translation] |